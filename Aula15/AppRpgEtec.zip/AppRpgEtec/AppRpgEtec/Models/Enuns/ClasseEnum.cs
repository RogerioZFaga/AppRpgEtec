﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppRpgEtec.Models.Enuns
{
    public enum ClasseEnum
    {
        NaoSelecionado=0,
        Cavaleiro=1,
        Mago=2,
        Clerigo=3
    }
}
